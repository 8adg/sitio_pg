# CSS Carousel

Create fast and lightweight (S)CSS carousel (slider) without JavaScript.

Read more on our [Blog](https://computerrock.com/blog/how-to-create-css-carousel-slider).
